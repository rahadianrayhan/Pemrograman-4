#include <iostream>
#include <vector>
using namespace std;

class Board {
	// 1. "independent" functionality
	vector < class Observer * > views; // 3. Coupled only to "interface"
		int p_x;
public:
	char square[10];
	void attach(Observer *obs) {
		views.push_back(obs);
	}
	void set_Coordinate(int x, char player) {
		square[x] = player;
		notify();
	}
	int get_x() {
		return p_x;
	}
	void notify();
};

class Observer {
	// 2. "dependent" functionality
	Board *board;
	int a_x, a_y;
public:
	Observer(Board *papan, int x, char player) {
		board = papan;
		board->set_Coordinate(x, player);
		// 4. Observers register themselves with the Subject
		board->attach(this);
	}
	virtual void update() = 0;
protected:
	Board * getBoard() {
		return board;
	}
};

void create_board(char square[]){
	cout << "\n\n\tTic Tac Toe\n\n";

	cout << "Player 1 (X)  -  Player 2 (O)" << endl << endl;
	cout << endl;

	cout << "     |     |     " << endl;
	cout << "  " << square[1] << "  |  " << square[2] << "  |  " << square[3] << endl;

	cout << "_____|_____|_____" << endl;
	cout << "     |     |     " << endl;

	cout << "  " << square[4] << "  |  " << square[5] << "  |  " << square[6] << endl;

	cout << "_____|_____|_____" << endl;
	cout << "     |     |     " << endl;

	cout << "  " << square[7] << "  |  " << square[8] << "  |  " << square[9] << endl;

	cout << "     |     |     " << endl << endl;
}

void Board::notify() {
	// 5. Publisher broadcasts
	for (int i = 0; i < views.size(); i++)views[i]->update();
}

class player_one : public Observer {
public:
	player_one(Board *papan, int x, char player) : Observer(papan, x, player) {}
	void update() {
		system("cls");
		create_board(getBoard()->square);
	}
};

class player_two : public Observer {
public:
	player_two(Board *papan, int x, char player) : Observer(papan, x, player) {}
	void update() {
		system("cls");
		create_board(getBoard()->square);
	}
};
int main() {
	int a;
	Board subj;
	player_one divObs1(&subj, 9, 'O'); // 7. Client configures the number and
	player_two divObs2(&subj, 7, 'X'); //    type of Observers
	cin >> a;
}